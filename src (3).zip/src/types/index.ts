//index.ts


// src/types.ts (or wherever your types are defined)

// ... existing types like Collection, MediaFile ...

export type UploadStatus = 'pending' | 'uploading' | 'success' | 'error';

export interface UploadableFile {
  id: string; // A unique ID for this upload instance (e.g., using Date.now() or a library)
  file: File;
  preview: string; // A base64 or blob URL for the image/video preview
  progress: number; // The upload progress from 0 to 100
  status: UploadStatus;
  error?: string; // The error message if the upload fails
  source?: any; // The request source, to allow for cancellation
}

export type FileType = 'image' | 'video' | 'audio';

export interface User {
  displayName: string;
  email: string;
  photoURL: string;
}

export interface HeaderProps {
  searchQuery: string;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  newCollectionName: string;
  onNewCollectionNameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onAddCollection: () => void;
  onAddCollectionKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  user: User | null;
  onSignOut: () => void;
}

export interface ProfileProps {
  user: User | null; // Allow user to be null
  onSignOut: () => void;
}

export interface MediaFile {
  url: string;
  type: string;
  name: string;
}

export interface FullscreenMedia extends MediaFile {
  collectionId: number;
}

export interface User {
  displayName: string;
  email: string;
  photoURL: string;
}

export interface Collection {
  id: number;
  title: string;
  note: string;
  files: Record<FileType, MediaFile[]>;
  tags: string[];
}

export interface ModalState {
  isOpen: boolean;
  message: string;
  onConfirm: (() => void) | null;
}

// Props Interfaces
export interface ModalProps {
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export interface FullscreenPreviewProps {
  media: FullscreenMedia | null;
  onClose: () => void;
  onDelete: (media: FullscreenMedia) => void;
}

export interface FilePreviewProps {
  file: MediaFile;
  onPreview: (file: MediaFile) => void;
  onDelete: (file: MediaFile) => void;
}

export interface FileUploadProps {
  type: FileType;
  files: MediaFile[];
  onFilesAdded: (files: File[]) => void;
  onPreview: (file: MediaFile) => void;
  onDelete: (file: MediaFile) => void;
}

export interface NoteAreaProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
}

export interface CollectionCardProps {
  collection: Collection;
  onUpdate: (id: number, updatedCollection: Collection) => void;
  onDelete: (id: number) => void;
  onPreview: (media: FullscreenMedia) => void;
  onDragStart: (e: React.DragEvent<HTMLDivElement>, id: number) => void;
  onDragOver: (e: React.DragEvent<HTMLDivElement>) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>, id: number) => void;
  requestMediaDelete: (media: FullscreenMedia) => void;
  isDragOver: boolean;
}
