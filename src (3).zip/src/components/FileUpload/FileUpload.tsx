import React, { useState, useRef } from 'react';
import FilePreview from '../FilePreview/FilePreview';
import type { FileUploadProps } from '../../types';
import styles from './FileUpload.module.css';

const FileUpload: React.FC<FileUploadProps> = ({ type, files, onFilesAdded, onPreview, onDelete }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const emojiMap = { image: '🖼️', video: '🎬', audio: '🎵' };
  const textMap = { image: 'Images', video: 'Videos', audio: 'Audios' };
  const acceptMap = { image: 'image/*', video: 'video/*', audio: 'audio/*' };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const droppedFiles = Array.from(e.dataTransfer.files);
    onFilesAdded(droppedFiles);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      onFilesAdded(Array.from(e.target.files));
    }
  };

  return (
    <div className="flex flex-col gap-2 w-full ">
      <div
        className={`border-2 p-4 rounded-md transition text-center cursor-pointer 
          ${isDragOver ? 'border-dashed border-zinc-400 bg-zinc-700' : 'border-zinc-600 bg-zinc-800'} 
          hover:bg-zinc-700 dark:hover:bg-zinc-700 text-zinc-300`}
        onClick={() => fileInputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragOver(false);
          handleDrop(e);
        }}
      >
        <span className="text-3xl">{emojiMap[type]}</span>
        <p className="text-sm mt-2">Drop {textMap[type]}</p>
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          multiple
          accept={acceptMap[type]}
          onChange={handleFileChange}
        />
      </div>

      <div className={`flex flex-wrap gap-2 ${styles.preview} ${type === 'audio' ? 'flex-col' : `flex-row p-2 rounded-md`}`}>
        {files.map((file, index) => (
          <FilePreview key={index} file={file} onPreview={onPreview} onDelete={onDelete} />
        ))}
      </div>
    </div>
  );
};

export default FileUpload;


//this