// src/App.tsx

import React, { useMemo } from 'react';
import { AnimatePresence } from 'framer-motion';

// Import your central types
import type { User as AppUser } from './types';

// Import your custom hooks
import { useAuth } from './hooks/useAuth';
import { useSync } from './hooks/useSync';

// Import UI Components
import HomePage from './components/HomePage/HomePage';
import Header from './components/Header/Header';
import CollectionList from './components/CollectionList/CollectionList';
import FullscreenPreview from './components/FullscreenPreview/FullscreenPreview';
import Modal from './components/Modal/Modal';

// Import Styles
import './App.css';

export default function App() {
  // Authentication hook
  const { user: firebaseUser, loading: authLoading, handleGoogleSignIn, handleSignOut } = useAuth();
  
  // Create a user object for display purposes, with fallback values
  const appUser: AppUser | null = useMemo(() => {
    if (!firebaseUser) return null;
    return {
      displayName: firebaseUser.displayName || 'Cloudkeep User',
      email: firebaseUser.email || 'No email provided',
      photoURL: firebaseUser.photoURL || '/default-avatar.png' // Ensure this image exists in your /public folder
    };
  }, [firebaseUser]);
  
  // Data synchronization hook - it receives the raw firebaseUser to perform queries
  const {
    loading: collectionsLoading,
    searchQuery, setSearchQuery,
    newCollectionName, setNewCollectionName,
    filteredCollections,
    handleAddCollection,
    handleDeleteCollection,
    handleFileUpload,
    handleTextUpdate,
    handleTagAdd,
    handleTagRemove,
    setFullscreenMedia,
    requestMediaDelete,
    dragHandlers,
    modal,
    hideModal,
    fullscreenMedia,
    toast
  } = useSync(firebaseUser);

  // Show a loading screen while Firebase checks for an active user session
  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-zinc-900">
        <p className="text-white">Initializing Cloudkeep...</p>
      </div>
    );
  }
  
  // If no user is logged in, show the landing page
  if (!firebaseUser) {
    return <HomePage onSignIn={handleGoogleSignIn} />;
  }
  
  // If the user is logged in, render the main application
  return (
    <div className="app-container bg-zinc-900 text-zinc-100 transition-colors duration-300 min-h-screen">
      <div className="p-4">
        <Header
          searchQuery={searchQuery}
          onSearchChange={(e) => setSearchQuery(e.target.value)}
          newCollectionName={newCollectionName}
          onNewCollectionNameChange={(e) => setNewCollectionName(e.target.value)}
          onAddCollection={handleAddCollection}
          onAddCollectionKeyDown={(e) => e.key === 'Enter' && handleAddCollection()}
          user={appUser}
          onSignOut={handleSignOut}
        />

        {/* Show a loading indicator while collections are being fetched from Firestore */}
        {collectionsLoading ? (
          <div className="text-center p-10 text-zinc-400">Loading collections...</div>
        ) : (
          <CollectionList
            collections={filteredCollections}
            // Pass down all the data modification functions
            onDelete={handleDeleteCollection}
            onFileUpload={handleFileUpload}
            onTextUpdate={handleTextUpdate}
            onTagAdd={handleTagAdd}
            onTagRemove={handleTagRemove}
            // Pass down other UI-related handlers
            onPreview={setFullscreenMedia}
            requestMediaDelete={requestMediaDelete}
            dragOverId={null} // You can implement the state for this in useSync if needed
            
            // --- ADD THESE PLACEHOLDER PROPS TO FIX THE ERROR ---
            onDragStart={() => console.log('Drag Started')} // Dummy function
            onDragOver={() => console.log('Drag Over')}   // Dummy function
            onDrop={() => console.log('Dropped')}         // Dummy function
          />
        )}

        {/* Modals and Overlays */}
        <AnimatePresence>
          {modal.isOpen && (
            <Modal
              message={modal.message}
              onConfirm={() => {
                // Safely call the onConfirm function if it exists
                if (modal.onConfirm) {
                  modal.onConfirm();
                }
                hideModal();
              }}
              onCancel={hideModal}
            />
          )}
          {fullscreenMedia && (
            <FullscreenPreview
              media={fullscreenMedia}
              onClose={() => setFullscreenMedia(null)}
              onDelete={requestMediaDelete}
            />
          )}
        </AnimatePresence>

        {/* Toast Notification */}
        <div className={`toast-notification ${toast.show ? 'show' : ''}`}>
          {toast.message}
        </div>
      </div>
    </div>
  );
}