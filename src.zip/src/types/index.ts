// src/types/index.ts

// This is for displaying user info in the UI
export interface User {
  displayName: string;
  email: string;
  photoURL: string;
}

export interface MediaFile {
  name: string;
  url: string;
  type: string;
}

export interface FullscreenMedia extends MediaFile {
  collectionId: string; // ID is a string
}

// This is the main data structure for a document in Firestore
export interface Collection {
  id: string; // Firestore document ID is a string
  title: string;
  noteText: string;
  createdAt: any; // Firestore Timestamp
  tags: string[];
  mediaFiles: MediaFile[];
}

export interface ModalState {
  isOpen: boolean;
  message: string;
  onConfirm: (() => void) | null;
}

// --- Component Prop Types ---

// Props required by the CollectionCard component
export interface CollectionCardProps {
  collection: Collection;
  isDragOver: boolean;
  onDelete: () => void;
  onPreview: (media: FullscreenMedia) => void;
  onTextUpdate: (updates: { title?: string; noteText?: string }) => void;
  onFileUpload: (file: File) => void;
  onTagAdd: (tag: string) => void;
  onTagRemove: (tag: string) => void;
  onDragStart: (e: React.DragEvent<HTMLDivElement>) => void;
  onDragOver: (e: React.DragEvent<HTMLDivElement>) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>) => void;
  requestMediaDelete: (media: FullscreenMedia) => void;
}