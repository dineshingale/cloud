// src/hooks/useSync.ts

import { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { db, storage } from '../firebase';
import {
  collection, query, onSnapshot, addDoc, updateDoc, doc,
  serverTimestamp, orderBy, arrayUnion, arrayRemove, deleteDoc, type DocumentData
} from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { type User as FirebaseUser } from 'firebase/auth';
import type { Collection, MediaFile, FullscreenMedia, ModalState } from '../types';

export function useSync(user: FirebaseUser | null) {
  // --- STATE MANAGEMENT ---
  const [rawCollections, setRawCollections] = useState<Collection[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [newCollectionName, setNewCollectionName] = useState('');
  
  // --- DRAG-AND-DROP STATE ---
  const dragItem = useRef<string | null>(null);
  const [dragOverId, setDragOverId] = useState<string | null>(null);

  // --- FIREBASE REAL-TIME DATA LISTENER ---
  useEffect(() => {
    if (user) {
      setLoading(true);
      const collectionsRef = collection(db, 'users', user.uid, 'collections');
      const q = query(collectionsRef, orderBy('createdAt', 'desc'));
      const unsubscribe = onSnapshot(q, (querySnapshot) => {
        const userCollections = querySnapshot.docs.map((doc: DocumentData) => ({
          id: doc.id,
          title: doc.data().title ?? '',
          noteText: doc.data().noteText ?? '',
          createdAt: doc.data().createdAt,
          tags: doc.data().tags ?? [],
          mediaFiles: doc.data().mediaFiles ?? [],
        })) as Collection[];
        setRawCollections(userCollections);
        setLoading(false);
      });
      return () => unsubscribe();
    } else {
      setRawCollections([]);
      setLoading(false);
    }
  }, [user]);

  // --- FILTERING LOGIC ---
  const filteredCollections = useMemo(() => {
    if (!searchQuery) return rawCollections;
    return rawCollections.filter(c => c.title.toLowerCase().includes(searchQuery.toLowerCase()));
  }, [rawCollections, searchQuery]);

  // --- DRAG-AND-DROP HANDLERS ---
  const onDragStart = useCallback((id: string) => {
    dragItem.current = id;
  }, []);

  const onDragOver = useCallback((id: string) => {
    setDragOverId(id);
  }, []);

  const onDrop = useCallback((id: string) => {
    if (dragItem.current === null || dragItem.current === id) {
      setDragOverId(null);
      return;
    }
    const fromIndex = rawCollections.findIndex(c => c.id === dragItem.current);
    const toIndex = rawCollections.findIndex(c => c.id === id);
    if (fromIndex === -1 || toIndex === -1) return;
    const newCollections = [...rawCollections];
    const [movedItem] = newCollections.splice(fromIndex, 1);
    newCollections.splice(toIndex, 0, movedItem);
    setRawCollections(newCollections);
    dragItem.current = null;
    setDragOverId(null);
  }, [rawCollections]);

  // --- FIREBASE DATA MODIFICATION FUNCTIONS ---
  const handleAddCollection = async () => {
    if (!user || newCollectionName.trim() === '') return;
    const collectionsRef = collection(db, 'users', user.uid, 'collections');
    await addDoc(collectionsRef, {
      title: newCollectionName,
      noteText: "Created on " + new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + " from Pune.",
      createdAt: serverTimestamp(),
      tags: [],
      mediaFiles: []
    });
    setNewCollectionName('');
  };

  const handleDeleteCollection = async (collectionId: string) => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid, 'collections', collectionId);
    await deleteDoc(docRef);
  };

  const handleFileUpload = async (collectionId: string, file: File) => {
    if (!user || !file) return;
    const storageRef = ref(storage, `${user.uid}/${collectionId}/${file.name}`);
    await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(storageRef);
    const docRef = doc(db, 'users', user.uid, 'collections', collectionId);
    await updateDoc(docRef, {
      mediaFiles: arrayUnion({ name: file.name, url: downloadURL, type: file.type })
    });
  };

  const handleTextUpdate = async (collectionId: string, updates: { title?: string; noteText?: string }) => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid, 'collections', collectionId);
    await updateDoc(docRef, updates);
  };

  const handleTagAdd = async (collectionId: string, tag: string) => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid, 'collections', collectionId);
    await updateDoc(docRef, { tags: arrayUnion(tag) });
  };

  const handleTagRemove = async (collectionId: string, tag: string) => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid, 'collections', collectionId);
    await updateDoc(docRef, { tags: arrayRemove(tag) });
  };

  // --- UI STATE AND FUNCTIONS ---
  const [modal, setModal] = useState<ModalState>({ isOpen: false, message: '', onConfirm: null });
  const [fullscreenMedia, setFullscreenMedia] = useState<FullscreenMedia | null>(null);
  const hideModal = () => setModal({ isOpen: false, message: '', onConfirm: null });
  const requestMediaDelete = () => alert("Delete media not implemented.");

  return {
    loading,
    searchQuery, setSearchQuery,
    newCollectionName, setNewCollectionName,
    filteredCollections,
    handleAddCollection, handleDeleteCollection, handleFileUpload,
    handleTextUpdate, handleTagAdd, handleTagRemove,
    dragOverId, onDragStart, onDragOver, onDrop,
    setFullscreenMedia, requestMediaDelete, modal, hideModal, fullscreenMedia,
  };
}