// src/components/CollectionList/CollectionList.tsx

import React from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import CollectionCard from '../CollectionCard/CollectionCard';
import type { Collection, FullscreenMedia } from '../../types';

// These props are passed down from App.tsx
interface CollectionListProps {
  collections: Collection[];
  dragOverId: string | null;
  onPreview: (media: FullscreenMedia) => void;
  // CRUD functions
  onDelete: (collectionId: string) => void;
  onTextUpdate: (collectionId: string, updates: { title?: string; noteText?: string }) => void;
  onFileUpload: (collectionId: string, file: File) => void;
  onTagAdd: (collectionId: string, tag: string) => void;
  onTagRemove: (collectionId: string, tag: string) => void;
  // Drag and other functions
  onDragStart: (e: React.DragEvent<HTMLDivElement>, id: string) => void;
  onDragOver: (e: React.DragEvent<HTMLDivElement>, id: string) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>, id: string) => void;
  requestMediaDelete: (media: FullscreenMedia) => void;
}

const CollectionList = ({ collections, dragOverId, ...props }: CollectionListProps) => {
  return (
    <main className="grid grid-cols-1 gap-4">
      <AnimatePresence>
        {collections.length > 0 ? (
          collections.map(c => (
            <CollectionCard
              key={c.id}
              collection={c}
              isDragOver={dragOverId === c.id}
              onPreview={props.onPreview}
              requestMediaDelete={props.requestMediaDelete}
              // Pass simplified functions to the card, baking in the collection ID
              onDelete={() => props.onDelete(c.id)}
              onTextUpdate={(updates) => props.onTextUpdate(c.id, updates)}
              onFileUpload={(file) => props.onFileUpload(c.id, file)}
              onTagAdd={(tag) => props.onTagAdd(c.id, tag)}
              onTagRemove={(tag) => props.onTagRemove(c.id, tag)}
              // Drag handlers
              onDragStart={(e) => props.onDragStart(e, c.id)}
              onDragOver={(e) => props.onDragOver(e, c.id)}
              onDrop={(e) => props.onDrop(e, c.id)}
            />
          ))
        ) : (
          <motion.div
            key="empty"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="text-center py-16 text-zinc-500"
          >
            <h2 className="text-2xl font-bold mb-2">No collections yet.</h2>
            <p>Created on Monday, August 4th, 2025 in Pune. Get started!</p>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
}

export default CollectionList;