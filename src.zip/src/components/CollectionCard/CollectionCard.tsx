// src/components/CollectionCard/CollectionCard.tsx

import React, { useState } from 'react';
import { motion } from 'framer-motion';

// This path should point to your central types definition file.
import type { Collection, FullscreenMedia, MediaFile, CollectionCardProps } from '../../types';

const CollectionCard: React.FC<CollectionCardProps> = ({
  collection,
  isDragOver,
  onDelete,
  onPreview,
  onTextUpdate,
  onFileUpload,
  onTagAdd,
  onTagRemove,
  requestMediaDelete,
  ...dragProps // This neatly contains onDragStart, onDragOver, onDrop
}) => {
  // Local state for managing UI within this specific card
  const [isEditingTitle, setIsEditingTitle] = useState(false);
  const [title, setTitle] = useState(collection.title);
  const [newTag, setNewTag] = useState('');

  // When the title input loses focus, call the update function if the title has changed
  const handleTitleBlur = () => {
    if (title.trim() && title !== collection.title) {
      onTextUpdate({ title });
    }
    setIsEditingTitle(false);
  };
  
  // Update the note text as the user types
  const handleNoteChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    onTextUpdate({ noteText: e.target.value });
  };
  
  // Handle file selection to trigger an upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onFileUpload(e.target.files[0]);
    }
  };

  // Add a new tag when the user presses Enter
  const handleTagKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && newTag.trim()) {
      e.preventDefault();
      onTagAdd(newTag.trim());
      setNewTag('');
    }
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.25, ease: 'easeInOut' }}
      className={`bg-zinc-800 text-zinc-100 rounded-xl shadow-lg transition-all duration-300 ease-in-out transform hover:scale-[1.01] ${
        isDragOver ? 'border-t-4 border-dashed border-blue-500' : 'border-t-4 border-transparent'
      }`}
    >
      <div
        className="p-4 flex flex-col gap-4"
        draggable
        {...dragProps} // Spread the drag event handlers (onDragStart, onDragOver, onDrop)
      >
        {/* --- HEADER: Title and Delete Button --- */}
        <div className="flex justify-between items-start gap-2">
          {isEditingTitle ? (
            <input
              value={title}
              onChange={e => setTitle(e.target.value)}
              onBlur={handleTitleBlur}
              onKeyDown={e => e.key === 'Enter' && handleTitleBlur()}
              className="text-xl font-semibold bg-transparent border-b border-zinc-500 focus:outline-none w-full"
              autoFocus
            />
          ) : (
            <h2 onDoubleClick={() => setIsEditingTitle(true)} className="text-xl font-semibold cursor-pointer break-all">
              {collection.title}
            </h2>
          )}
          <button onClick={onDelete} className="text-zinc-500 hover:text-red-500 transition-colors flex-shrink-0">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="currentColor" viewBox="0 0 16 16"><path d="M5.5 5.5A.5.5 0 0 1 6 6v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m2.5 0a.5.5 0 0 1 .5.5v6a.5.5 0 0 1-1 0V6a.5.5 0 0 1 .5-.5m3 .5a.5.5 0 0 0-1 0v6a.5.5 0 0 0 1 0z"/><path d="M14.5 3a1 1 0 0 1-1 1H13v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V4h-.5a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1H6a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1h3.5a1 1 0 0 1 1 1zM4.118 4 4 4.059V13a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V4.059L11.882 4zM2.5 3h11V2h-11z"/></svg>
          </button>
        </div>

        {/* --- CONTENT: Note, Files, and Upload --- */}
        <textarea
          value={collection.noteText}
          onChange={handleNoteChange}
          placeholder="Write your note here..."
          className="w-full bg-zinc-700 rounded p-2 text-zinc-200 focus:outline-none focus:ring-2 focus:ring-blue-500"
          rows={4}
        />

        {/* Display existing media files */}
        <div className="flex flex-col gap-1">
            {collection.mediaFiles?.map((file) => (
                <a key={file.url} href={file.url} target="_blank" rel="noopener noreferrer" className="text-blue-400 text-sm hover:underline truncate">
                    {file.name}
                </a>
            ))}
        </div>

        <input type="file" onChange={handleFileChange} className="text-sm text-zinc-400 file:mr-4 file:py-1 file:px-2 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-500 file:text-white hover:file:bg-blue-600 cursor-pointer"/>

        {/* --- FOOTER: Tags --- */}
        <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-zinc-700">
          {collection.tags?.map(tag => (
            <div key={tag} className="bg-zinc-600 text-zinc-200 text-xs font-semibold px-2 py-1 rounded-full flex items-center gap-1">
              <span>{tag}</span>
              <button onClick={() => onTagRemove(tag)} className="text-zinc-400 hover:text-white transition-colors">&times;</button>
            </div>
          ))}
          <input
            type="text"
            value={newTag}
            onChange={e => setNewTag(e.target.value)}
            onKeyDown={handleTagKeyDown}
            placeholder="+ Add tag"
            className="bg-zinc-700 text-sm text-zinc-100 placeholder-zinc-400 px-2 py-1 rounded-full focus:outline-none focus:ring-2 focus:ring-zinc-400 transition"
          />
        </div>
      </div>
    </motion.div>
  );
};

export default CollectionCard;