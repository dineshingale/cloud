// src/hooks/useAuth.ts

import { useState, useEffect } from 'react';
import {
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  type User
} from 'firebase/auth';
import { auth } from '../firebase'; // Import our initialized auth service

export function useAuth() {
  // State to hold the current user object from Firebase
  const [user, setUser] = useState<User | null>(null);
  
  // State to know if the initial auth check is complete
  const [loading, setLoading] = useState(true);

  // Set up a listener that fires whenever the user's sign-in state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false); // Auth check is complete
    });

    // Cleanup the listener when the component unmounts
    return () => unsubscribe();
  }, []); // The empty array ensures this effect runs only once

  // Function to trigger the Google Sign-In popup
  const handleGoogleSignIn = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Error during Google sign-in:", error);
    }
  };

  // Function to sign the user out
  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error("Error during sign-out:", error);
    }
  };

  // Expose the user, loading state, and functions to the rest of the app
  return { user, loading, handleGoogleSignIn, handleSignOut };
}