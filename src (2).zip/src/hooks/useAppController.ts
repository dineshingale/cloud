// src/hooks/useAppController.ts

import { useState, useCallback } from 'react';
import type { FullscreenMedia, User as AppUser, Collection } from '../types';
import { type User as FirebaseUser } from 'firebase/auth';

// Import the NEW data hook and other UI hooks
import { useSync } from './useSync';
import { useModal } from './useModal';
import { useToast } from './useToast';

export function useAppController(firebaseUser: FirebaseUser | null) {
  // --- Low-level hooks ---
  const { modal, showModal, hideModal } = useModal();
  const { toast, showToast } = useToast();
  const {
    loading,
    filteredCollections,
    // Renaming for clarity inside this hook
    handleAddCollection: addCollectionToDb,
    handleDeleteCollection: deleteCollectionFromDb,
    handleTextUpdate,
    handleFileUpload,
    handleTagAdd,
    handleTagRemove,
    dragOverId, onDragStart, onDragOver, onDrop,
    setFullscreenMedia, fullscreenMedia,
  } = useSync(firebaseUser);

  // --- UI State managed by this controller ---
  const [searchQuery, setSearchQuery] = useState('');
  // ADD THIS LINE: This hook now owns the state for the new collection input
  const [newCollectionName, setNewCollectionName] = useState('');

  // --- High-level handlers that combine data logic with UI feedback ---

  const handleAddCollection = useCallback(() => {
    if (newCollectionName.trim() === '') return;
    addCollectionToDb(newCollectionName); // Call the function from useSync with the state
    setNewCollectionName(''); // Clear the input field's state
    showToast('Collection created!');
  }, [newCollectionName, addCollectionToDb, showToast]);

  const handleDeleteCollection = useCallback((collectionId: string) => { // ID is a string
    showModal('Are you sure you want to delete this collection permanently?', () => {
      deleteCollectionFromDb(collectionId);
      showToast('Collection deleted!');
    });
  }, [showModal, deleteCollectionFromDb, showToast]);

  // A placeholder for media deletion logic
  const requestMediaDelete = useCallback((media: FullscreenMedia) => {
    showModal('Are you sure you want to delete this file?', () => {
      // To implement this, you would add a `handleMediaDelete` function to useSync
      alert('Media deletion needs to be implemented in useSync.ts');
      showToast('Media deleted!');
    });
  }, [showModal, showToast]);

  // Return everything the UI needs from all hooks, consolidated
  return {
    loading,
    searchQuery, setSearchQuery,
    // This state is now provided from this hook
    newCollectionName, setNewCollectionName,
    filteredCollections,
    // Pass down the high-level handlers
    handleAddCollection,
    handleDeleteCollection,
    requestMediaDelete,
    // Pass down the granular update functions directly from useSync
    handleTextUpdate,
    handleFileUpload,
    handleTagAdd,
    handleTagRemove,
    // Pass down UI state and handlers
    dragOverId, onDragStart, onDragOver, onDrop,
    modal, hideModal,
    fullscreenMedia, setFullscreenMedia,
    toast,
  };
}