// src/types/index.ts

// --- CORE DATA TYPES ---

export type FileType = 'image' | 'video' | 'audio';

// For displaying user info in the UI (derived from Firebase User)
export interface User {
  displayName: string;
  email: string;
  photoURL: string;
}

export interface MediaFile {
  name: string;
  url: string;
  type: string;
}

export interface FullscreenMedia extends MediaFile {
  collectionId: string; // Firestore document ID is a string
}

// The main data structure for a document in our Firestore database
export interface Collection {
  id: string; // Firestore document ID is a string
  title: string;
  noteText: string;
  createdAt: any; // Can be a Firestore Timestamp or a Date object
  tags: string[];
  mediaFiles: MediaFile[];
}

// Defines the shape of the modal's state object
export interface ModalState {
  isOpen: boolean;
  message: string;
  onConfirm: (() => void) | null;
}


// --- COMPONENT PROPS INTERFACES ---

export interface HeaderProps {
  searchQuery: string;
  onSearchChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  newCollectionName: string;
  onNewCollectionNameChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onAddCollection: () => void;
  onAddCollectionKeyDown: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  user: User | null;
  onSignOut: () => void;
}

export interface ProfileProps {
  user: User | null;
  onSignOut: () => void;
}

export interface CollectionListProps {
  collections: Collection[];
  dragOverId: string | null;
  onPreview: (media: FullscreenMedia) => void;
  // CRUD functions that include the collectionId
  onDelete: (collectionId: string) => void;
  onTextUpdate: (collectionId: string, updates: { title?: string; noteText?: string }) => void;
  onFileUpload: (collectionId: string, file: File) => void;
  onTagAdd: (collectionId: string, tag: string) => void;
  onTagRemove: (collectionId: string, tag: string) => void;
  // Drag handlers that include the id
  onDragStart: (e: React.DragEvent<HTMLDivElement>, id: string) => void;
  onDragOver: (e: React.DragEvent<HTMLDivElement>, id: string) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>, id: string) => void;
  requestMediaDelete: (media: FullscreenMedia) => void;
}

export interface CollectionCardProps {
  collection: Collection;
  isDragOver: boolean;
  onDelete: () => void;
  onPreview: (media: FullscreenMedia) => void;
  // Specific update functions for granular Firebase updates
  onTextUpdate: (updates: { title?: string; noteText?: string }) => void;
  onFileUpload: (file: File) => void;
  onTagAdd: (tag: string) => void;
  onTagRemove: (tag: string) => void;
  // Drag and drop handlers are simplified as the ID is handled by the parent
  onDragStart: (e: React.DragEvent<HTMLDivElement>) => void;
  onDragOver: (e: React.DragEvent<HTMLDivElement>) => void;
  onDrop: (e: React.DragEvent<HTMLDivElement>) => void;
  requestMediaDelete: (media: FullscreenMedia) => void;
}

export interface ModalProps {
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export interface FullscreenPreviewProps {
  media: FullscreenMedia | null;
  onClose: () => void;
  onDelete: (media: FullscreenMedia) => void;
}

export interface NoteAreaProps {
  value: string;
  onChange: (e: React.ChangeEvent<HTMLTextAreaElement>) => void;
}

export interface FileUploadProps {
  type: FileType;
  files: MediaFile[];
  onFilesAdded: (files: File[]) => void;
  onPreview: (file: MediaFile) => void;
  onDelete: (file: MediaFile) => void;
}

export interface FilePreviewProps {
  file: MediaFile;
  onPreview: (file: MediaFile) => void;
  onDelete: (file: MediaFile) => void;
}