// src/App.tsx

import React, { useMemo, useState } from 'react'; // Make sure useState is imported
import { AnimatePresence } from 'framer-motion';

// Import your central types
import type { User as AppUser } from './types';

// Import your custom hooks
import { useAuth } from './hooks/useAuth';
import { useSync } from './hooks/useSync';

// Import UI Components
import HomePage from './components/HomePage/HomePage';
import Header from './components/Header/Header';
import CollectionList from './components/CollectionList/CollectionList';
import FullscreenPreview from './components/FullscreenPreview/FullscreenPreview';
import Modal from './components/Modal/Modal';

// Import Styles
import './App.css';

export default function App() {
  const { user: firebaseUser, loading: authLoading, handleGoogleSignIn, handleSignOut } = useAuth();
  
  const appUser: AppUser | null = useMemo(() => {
    if (!firebaseUser) return null;
    return {
      displayName: firebaseUser.displayName || 'Cloudkeep User',
      email: firebaseUser.email || 'No email provided',
      photoURL: firebaseUser.photoURL || '/default-avatar.png'
    };
  }, [firebaseUser]);
  
  // ADDED: App.tsx now manages the state for the new collection input field.
  const [newCollectionName, setNewCollectionName] = useState('');

  // CHANGED: The hook no longer provides newCollectionName or setNewCollectionName.
  const {
    loading: collectionsLoading,
    searchQuery, setSearchQuery,
    filteredCollections,
    handleAddCollection, // This function now expects the title as an argument
    handleDeleteCollection, handleFileUpload,
    handleTextUpdate, handleTagAdd, handleTagRemove,
    dragOverId, onDragStart, onDragOver, onDrop,
    setFullscreenMedia, requestMediaDelete, modal, hideModal, fullscreenMedia,
  } = useSync(firebaseUser);

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-zinc-900">
        <p className="text-white">Initializing Cloudkeep...</p>
      </div>
    );
  }
  
  if (!firebaseUser) {
    return <HomePage onSignIn={handleGoogleSignIn} />;
  }
  
  return (
    <div className="app-container bg-zinc-900 text-zinc-100 min-h-screen">
      <div className="p-4">
        <Header
          searchQuery={searchQuery}
          onSearchChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
          newCollectionName={newCollectionName}
          onNewCollectionNameChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewCollectionName(e.target.value)}
          // CHANGED: Pass the state to the function and then clear it.
          onAddCollection={() => {
            handleAddCollection(newCollectionName);
            setNewCollectionName('');
          }}
          onAddCollectionKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
            if (e.key === 'Enter') {
              handleAddCollection(newCollectionName);
              setNewCollectionName('');
            }
          }}
          user={appUser}
          onSignOut={handleSignOut}
        />

        {collectionsLoading ? (
          <div className="text-center p-10 text-zinc-400">Loading collections...</div>
        ) : (
          <CollectionList
            collections={filteredCollections}
            onDelete={handleDeleteCollection}
            onFileUpload={handleFileUpload}
            onTextUpdate={handleTextUpdate}
            onTagAdd={handleTagAdd}
            onTagRemove={handleTagRemove}
            onPreview={setFullscreenMedia}
            requestMediaDelete={requestMediaDelete}
            dragOverId={dragOverId}
            onDragStart={onDragStart}
            onDragOver={onDragOver}
            onDrop={onDrop}
          />
        )}

        <AnimatePresence>
          {modal.isOpen && (
            <Modal
              message={modal.message}
              onConfirm={() => {
                if (modal.onConfirm) {
                  modal.onConfirm();
                }
                hideModal();
              }}
              onCancel={hideModal}
            />
          )}
          {fullscreenMedia && (
            <FullscreenPreview
              media={fullscreenMedia}
              onClose={() => setFullscreenMedia(null)}
              onDelete={requestMediaDelete}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}