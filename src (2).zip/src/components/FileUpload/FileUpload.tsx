import React, { useState, useRef } from 'react';
import styles from './FileUpload.module.css';
import FilePreview from '../FilePreview/FilePreview';
import type { FileUploadProps } from '../../types';

const FileUpload: React.FC<FileUploadProps> = ({ type, files, onFilesAdded, onPreview, onDelete }) => {
  const [isHover, setIsHover] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const emojiMap = { image: '🖼️', video: '🎬', audio: '🎵' };
  const textMap = { image: 'Images', video: 'Videos', audio: 'Audios' };
  const acceptMap = { image: 'image/*', video: 'video/*', audio: 'audio/*' };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsHover(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    onFilesAdded(droppedFiles);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      onFilesAdded(Array.from(e.target.files));
    }
  };

  return (
    <div className={styles.wrapper}>
      <div
        className={`border-2 p-4 rounded-md transition text-center cursor-pointer ${
          isDragOver
            ? 'border-dashed border-zinc-400 bg-zinc-700'
            : 'border-zinc-600 bg-zinc-800'
        }`}
        onClick={() => fileInputRef.current?.click()}
        onDragOver={(e) => {
          e.preventDefault();
          setIsDragOver(true);
        }}
        onDragLeave={() => setIsDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setIsDragOver(false);
          handleDrop(e);
        }}
      >
        <span className="text-3xl">{emojiMap[type]}</span>
        <p className="text-sm text-zinc-300">Drop {textMap[type]}</p>
        <input
          ref={fileInputRef}
          type="file"
          className="hidden"
          multiple
          accept={acceptMap[type]}
          onChange={handleFileChange}
        />
      </div>

      <div className={`${styles.preview} ${type === 'audio' ? styles.column : styles.row}`}>
        {files.map((file, index) => (
          <FilePreview key={index} file={file} onPreview={onPreview} onDelete={onDelete} />
        ))}
      </div>
    </div>
  );
};

export default FileUpload;
